#include "headingtests.hpp"
#include "../src/Logger.cpp"
#include <gtest/gtest.h>

TEST(a, b) { EXPECT_EQ(1, 2); }